# CoC 명세서 작성 보완자료 V01

project_id: safety-constrained-coc

발명내용설명서 V02 PDF/DOCX, 보완자료 PDF/DOCX, 수치 확인용 JSON, 기반 논문 PDF, 회신 초안입니다.
발명내용설명서는 전체 발명 구성·도면·예비 청구항을, 보완자료는 생성·활용 실시예를 설명합니다.
JSON의 정답은 규칙 기반 산출값이며 새 모델 추론 결과가 아닙니다.
공개 참고 문헌의 공식 링크는 보완자료 9절에 있습니다.

## 첨부 파일 SHA-256

- coc_invention_disclosure_v02.pdf: `c4f36eeb50043fec69158519c0ae93afae3414ffe56fe098b38eca04bcb33051`
- coc_invention_disclosure_v02.docx: `87c947a2686fc0e4b885b2bd6fa060a05a9f7ec37c1739c61fc0860c1b8042cb`
- coc_generation_usage_supplement_v01.pdf: `f1a0457cce6939779a1ba6f651aa893da57a126cb6324d9abe44ec31de417626`
- coc_generation_usage_supplement_v01.docx: `243eb1420a1df089ca7c7cf5ad0f635274ea0444c929aa0829bb63a4196d8e6d`
- coc_generation_usage_examples_v01.json: `037302240419fc5331f64e7a089ba999c7422af74525264dae6d73d96b5785bd`
- safety_constrained_coc_paper.pdf: `2cced782c9ca10725d2d695129de41cf61f5989b1c6ea7b7f1e08ce6ea4d449e`
- COC_SUPPLEMENT_REPLY_DRAFT_V01.md: `53165847cce080ad711feb6c626c6258036027a146c96bb207dbff909d44f16c`
